Tuldok frozen release v1. Asset paths are relative to archive root.
COCO projections contain detection only. JSONL contains other task records.
Text spans index Unicode code points in canonical text, not UTF-16 or bytes.
See manifest.json for revisions, lineage, review, vocabulary and split report.
