Tuldok text_instruction_v1. Consumer rows have only prompt/completion.
Load the nonempty train/validation/test data.jsonl files with explicit split mappings.
rows.jsonl maps zero-based rows to fixed response/parent/source revisions and family IDs.
manifest.json preserves canonical evidence. Completion text is never trimmed or normalized.
Consumer token limits/EOS/loss configuration are explicit training choices.
