Tuldok text_preference_v1. Explicit prompt/chosen/rejected strings.
Only independently human-reviewed directional judgments yield rows.
Ties/abstentions are excluded with reasons in manifest.json.
rows.jsonl binds exact judgment/prompt/answer revisions and whole source family.
Answer review is evidence, not a preference. EOS/padding/truncation are consumer settings.
